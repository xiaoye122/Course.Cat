# ========== POI（你项目里用到了） ==========
-dontwarn java.awt.Color
-dontwarn java.awt.Dimension
-dontwarn java.awt.Rectangle
-keep class org.apache.poi.hssf.record.** { *; }

# ========== QQ API 数据类，防止 Gson 反射解析失败 ==========
-keep class com.star.schedule.ui.layouts.QQInfoResponse { *; }
-keep class com.star.schedule.ui.layouts.MemberInfo { *; }

# ========== Gson 通用规则 ==========
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes RuntimeVisibleAnnotations
-keepattributes RuntimeVisibleParameterAnnotations
-keepattributes InnerClasses
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# ========== OkHttp / Okio ==========
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# ========== Coil ==========
-keep class coil.** { *; }
-dontwarn coil.**

# ========== Kotlin Coroutines ==========
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**


# ========== Apache POI 完整豁免（导出 xls 需要） ==========
-keep class org.apache.poi.** { *; }
-dontwarn org.apache.poi.**

# POI 依赖的可选/缺失类，全部忽略
-dontwarn javax.xml.bind.**
-dontwarn javax.xml.stream.**
-dontwarn javax.xml.**
-dontwarn javax.imageio.**
-dontwarn javax.management.**
-dontwarn java.awt.**
-dontwarn java.lang.management.**
-dontwarn org.apache.xmlbeans.**
-dontwarn org.apache.logging.log4j.**
-dontwarn org.apache.commons.**
-dontwarn org.w3c.dom.**
-dontwarn org.xml.sax.**
-dontwarn com.microsoft.schemas.**
-dontwarn com.graphbuilder.**
-dontwarn org.etsi.**
-dontwarn org.openxmlformats.**
-dontwarn schemasMicrosoftComVml.**
-dontwarn schemasMicrosoftComOfficeExcel.**
-dontwarn schemasMicrosoftComOfficeOffice.**
-dontwarn schemasMicrosoftComOfficePowerpoint.**
-dontwarn schemasMicrosoftComOfficeWord.**