package com.star.schedule.utils.parser

import android.content.Context
import android.net.Uri
import com.star.schedule.R
import com.star.schedule.db.ScheduleDao
import com.star.schedule.db.TimetableEntity
import com.star.schedule.utils.ValidationUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * 课表导出为 .xls / .csv / .html 文件
 *
 * 注意: 不使用任何 CellStyle / Font，因为 POI 的 createCellStyle()
 * 会触发 HSSFColor.HSSFColorPredefined 初始化，而它引用了 Android
 * 不存在的 java.awt.Color，导致运行时 NoClassDefFoundError。
 *
 * 所以 xls 只写纯数据，不加样式。
 *
 * 单元格内容格式(与 SimpleTimetableParser 对应):
 *   第1行: 课名
 *   第2行: @教师    (可选, 以 @ 开头)
 *   第3行: 地点     (可选)
 *   第4行: 周次     (可选, 如 "1-16周")
 */
object TimetableExcelExporter {

    // ============================================================
    //  XLS 导出
    // ============================================================
    suspend fun exportTimetableToXls(
        context: Context,
        uri: Uri,
        timetable: TimetableEntity,
        dao: ScheduleDao
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // ---------- 1. 拉数据 ----------
            val lessonTimes = dao.getLessonTimesFlow(timetable.id)
                .firstOrNull()
                .orEmpty()
                .sortedBy { it.period }

            val courses = dao.getCoursesFlow(timetable.id)
                .firstOrNull()
                .orEmpty()

            // ---------- 2. 工作簿 ----------
            val workbook = HSSFWorkbook()
            val sheet = workbook.createSheet(sanitizeSheetName(timetable.name))

            // ---------- 3. 表头(无样式) ----------
            val headerRow = sheet.createRow(0)
            headerRow.setHeightInPoints(24f)
            headerRow.createCell(0).setCellValue(
                context.getString(R.string.excel_header_period)
            )

            val dayResIds = listOf(
                R.string.excel_header_monday,
                R.string.excel_header_tuesday,
                R.string.excel_header_wednesday,
                R.string.excel_header_thursday,
                R.string.excel_header_friday,
                R.string.excel_header_saturday,
                R.string.excel_header_sunday
            )
            dayResIds.forEachIndexed { index, resId ->
                headerRow.createCell(index + 1).setCellValue(context.getString(resId))
            }

            // ---------- 4. 数据行(无样式) ----------
            if (lessonTimes.isEmpty()) {
                val row = sheet.createRow(1)
                row.createCell(0).setCellValue(
                    context.getString(R.string.excel_empty_hint)
                )
                for (day in 1..7) {
                    row.createCell(day).setCellValue("")
                }
            } else {
                lessonTimes.forEachIndexed { rowIndex, lesson ->
                    val row = sheet.createRow(rowIndex + 1)
                    row.setHeightInPoints(60f)

                    row.createCell(0).setCellValue(
                        context.getString(
                            R.string.excel_period_time_format,
                            lesson.period,
                            lesson.startTime,
                            lesson.endTime
                        )
                    )

                    for (day in 1..7) {
                        val matched = courses.filter { course ->
                            course.dayOfWeek == day && course.periods.contains(lesson.period)
                        }
                        val text = if (matched.isEmpty()) {
                            ""
                        } else {
                            matched.joinToString("\n") { course ->
                                buildString {
                                    append(course.name)
                                    if (course.teacher.isNotBlank()) {
                                        append("\n@").append(course.teacher)
                                    }
                                    if (course.location.isNotBlank()) {
                                        append("\n").append(course.location)
                                    }
                                    if (course.weeks.isNotEmpty()) {
                                        append("\n").append(formatWeeks(course.weeks))
                                    }
                                }
                            }
                        }
                        row.createCell(day).setCellValue(text)
                    }
                }
            }

            // ---------- 5. 列宽 ----------
            sheet.setColumnWidth(0, 14 * 256)
            for (day in 1..7) {
                sheet.setColumnWidth(day, 18 * 256)
            }

            // ---------- 6. 写出 ----------
            context.contentResolver.openOutputStream(uri)?.use { os ->
                workbook.write(os)
                os.flush()
            } ?: return@withContext Result.failure(
                IllegalStateException("Cannot open output stream, uri=$uri")
            )

            workbook.close()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ============================================================
    //  CSV 导出
    // ============================================================
    suspend fun exportTimetableToCsv(
        context: Context,
        uri: Uri,
        timetable: TimetableEntity,
        dao: ScheduleDao
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val lessonTimes = dao.getLessonTimesFlow(timetable.id)
                .firstOrNull().orEmpty()
                .sortedBy { it.period }
            val courses = dao.getCoursesFlow(timetable.id)
                .firstOrNull().orEmpty()

            val csvContent = buildString {
                append("课程名称,教师,地点,星期,节次,周次\n")
                courses.forEach { course ->
                    val periods = ValidationUtils.CourseValidation.formatNumberList(course.periods)
                    val weeks = ValidationUtils.CourseValidation.formatNumberList(course.weeks)
                    append("${escapeCsv(course.name)},")
                    append("${escapeCsv(course.teacher)},")
                    append("${escapeCsv(course.location)},")
                    append("${course.dayOfWeek},")
                    append("$periods,")
                    append("$weeks\n")
                }
                append("\n课程时间表\n")
                append("节次,开始时间,结束时间\n")
                lessonTimes.forEach { lesson ->
                    append("${lesson.period},${lesson.startTime},${lesson.endTime}\n")
                }
            }

            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                // UTF-8 BOM，确保 Excel 识别中文
                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
            } ?: return@withContext Result.failure(Exception("无法打开输出流"))

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ============================================================
    //  HTML 导出
    // ============================================================
    suspend fun exportTimetableToHtml(
        context: Context,
        uri: Uri,
        timetable: TimetableEntity,
        dao: ScheduleDao
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val lessonTimes = dao.getLessonTimesFlow(timetable.id)
                .firstOrNull().orEmpty()
                .sortedBy { it.period }
            val courses = dao.getCoursesFlow(timetable.id)
                .firstOrNull().orEmpty()

            val htmlContent = buildString {
                append(
                    """
                    <!DOCTYPE html>
                    <html lang="zh-CN">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>${escapeHtml(timetable.name)} - 课程表</title>
                        <style>
                            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 20px; }
                            h1 { color: #333; }
                            h2 { color: #666; margin-top: 30px; }
                            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
                            th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
                            th { background-color: #f5f5f5; font-weight: bold; }
                            tr:nth-child(even) { background-color: #fafafa; }
                            .meta { color: #888; font-size: 0.9em; margin-top: 20px; }
                        </style>
                    </head>
                    <body>
                        <h1>${escapeHtml(timetable.name)}</h1>
                        <p class="meta">学期开始日期: ${timetable.startDate}</p>
                        <h2>课程列表</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>课程名称</th><th>教师</th><th>地点</th>
                                    <th>星期</th><th>节次</th><th>周次</th>
                                </tr>
                            </thead>
                            <tbody>
                    """.trimIndent()
                )
                append("\n")

                courses.forEach { course ->
                    val periods = ValidationUtils.CourseValidation.formatNumberList(course.periods)
                    val weeks = ValidationUtils.CourseValidation.formatNumberList(course.weeks)
                    append(
                        """
                                <tr>
                                    <td>${escapeHtml(course.name)}</td>
                                    <td>${escapeHtml(course.teacher)}</td>
                                    <td>${escapeHtml(course.location)}</td>
                                    <td>${getDayOfWeekName(course.dayOfWeek)}</td>
                                    <td>$periods</td>
                                    <td>$weeks</td>
                                </tr>
                        """.trimIndent()
                    )
                    append("\n")
                }

                append(
                    """
                            </tbody>
                        </table>
                        <h2>课程时间表</h2>
                        <table>
                            <thead>
                                <tr><th>节次</th><th>开始时间</th><th>结束时间</th></tr>
                            </thead>
                            <tbody>
                    """.trimIndent()
                )
                append("\n")

                lessonTimes.forEach { lesson ->
                    append(
                        """
                                <tr>
                                    <td>第 ${lesson.period} 节</td>
                                    <td>${lesson.startTime}</td>
                                    <td>${lesson.endTime}</td>
                                </tr>
                        """.trimIndent()
                    )
                    append("\n")
                }

                append(
                    """
                            </tbody>
                        </table>
                        <p class="meta">导出时间: ${
                        LocalDateTime.now().format(
                            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                        )
                    }</p>
                    </body>
                    </html>
                    """.trimIndent()
                )
            }

            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(htmlContent.toByteArray(Charsets.UTF_8))
            } ?: return@withContext Result.failure(Exception("无法打开输出流"))

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ============================================================
    //  内部工具方法
    // ============================================================

    /**
     * 把 [1,2,3,5,6,7,10] 格式化成 "1-3,5-7,10周"
     */
    private fun formatWeeks(weeks: List<Int>): String {
        if (weeks.isEmpty()) return ""
        val sorted = weeks.distinct().sorted()
        val sb = StringBuilder()

        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1..sorted.size) {
            val cur = sorted.getOrNull(i)
            if (cur != null && cur == prev + 1) {
                prev = cur
                continue
            }
            if (sb.isNotEmpty()) sb.append(",")
            if (start == prev) {
                sb.append(start)
            } else {
                sb.append(start).append("-").append(prev)
            }
            if (cur != null) {
                start = cur
                prev = cur
            }
        }
        return "${sb}周"
    }

    private fun sanitizeSheetName(name: String): String {
        val cleaned = name
            .replace(Regex("""[\\/:*?\[\]]"""), "_")
            .trim()
            .take(31)
        return cleaned.ifEmpty { "Timetable" }
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(',') || value.contains('"') || value.contains('\n')) {
            "\"${value.replace("\"", "\"\"")}\""
        } else value
    }

    private fun escapeHtml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")

    private fun getDayOfWeekName(day: Int): String = when (day) {
        1 -> "周一"; 2 -> "周二"; 3 -> "周三"; 4 -> "周四"
        5 -> "周五"; 6 -> "周六"; 7 -> "周日"; else -> "未知"
    }
}