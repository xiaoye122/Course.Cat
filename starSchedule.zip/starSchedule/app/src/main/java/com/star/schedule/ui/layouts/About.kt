package com.star.schedule.ui.layouts

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import coil.compose.AsyncImage
import com.google.gson.Gson
import com.star.schedule.R
import com.star.schedule.ui.theme.StarScheduleTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit


// ==================================================================
// ===== 更新检查相关 =====
// ==================================================================

private const val TAG = "UpdateChecker"
private const val GITHUB_REPO = "xiaoye122/Course.Cat"

sealed class UpdateResult {
    data object NoUpdate : UpdateResult()
    data class HasUpdate(val latestTag: String, val currentVersion: String) : UpdateResult()
    data object Failed : UpdateResult()
}

/**
 * 获取 GitHub 最新 release 的 tag_name
 */
suspend fun fetchLatestReleaseTag(): String? = withContext(Dispatchers.IO) {
    try {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()

        val url = "https://api.github.com/repos/$GITHUB_REPO/releases/latest"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/vnd.github+json")
            .build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                Log.w(TAG, "GitHub API failed: code=${resp.code}, msg=${resp.message}")
                return@withContext null
            }
            val body = resp.body?.string()
            if (body.isNullOrBlank()) {
                Log.w(TAG, "Empty body from GitHub API")
                return@withContext null
            }
            val tag = JSONObject(body).optString("tag_name", "").ifBlank { null }
            Log.d(TAG, "Fetched latest tag: $tag")
            tag
        }
    } catch (e: javax.net.ssl.SSLHandshakeException) {
        Log.w(TAG, "SSL handshake failed", e)
        null
    } catch (e: java.net.SocketTimeoutException) {
        Log.w(TAG, "Request timeout", e)
        null
    } catch (e: java.net.UnknownHostException) {
        Log.w(TAG, "Unknown host", e)
        null
    } catch (e: java.net.ConnectException) {
        Log.w(TAG, "Connect failed", e)
        null
    } catch (e: Exception) {
        Log.w(TAG, "Failed to fetch latest release tag", e)
        null
    }
}

/**
 * 比较版本号。latestTag > currentVersion 时返回 true
 * 支持 vX.Y.Z 格式，忽略 v 前缀，缺位补 0
 */
fun isNewerVersion(latestTag: String, currentVersion: String): Boolean {
    val lt = latestTag.trimStart('v', 'V').split(".")
    val cv = currentVersion.trimStart('v', 'V').split(".")
    val len = maxOf(lt.size, cv.size)
    for (i in 0 until len) {
        val l = lt.getOrNull(i)?.toIntOrNull() ?: 0
        val c = cv.getOrNull(i)?.toIntOrNull() ?: 0
        if (l > c) return true
        if (l < c) return false
    }
    return false
}


// ==================================================================
// ===== AboutActivity =====
// ==================================================================

class AboutActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StarScheduleTheme {
                AboutScreen(onBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val versionName = remember {
        runCatching {
            context.packageManager
                .getPackageInfo(context.packageName, 0)
                .versionName
        }.getOrNull() ?: "1.0.0"
    }

    var showSponsorDialog by remember { mutableStateOf(false) }
    var introExpanded by rememberSaveable { mutableStateOf(false) }

    // ===== 更新状态 =====
    var isCheckingUpdate by remember { mutableStateOf(false) }
    var updateResult by remember { mutableStateOf<UpdateResult?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("关于") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ===== 上方：可滚动内容 =====
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))

                // ===== 顶部：应用图标 + 名称 + 版本 =====
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.tertiary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = null,
                        modifier = Modifier.size(64.dp)
                    )
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    text = "星课程",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = "版本 $versionName",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(24.dp))

                // ===== 简介卡片 =====
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "简介",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "一款简洁、优雅的课程表 App，支持课前提醒、桌面小组件、Flyme 实况通知等特性。",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // ===== 开发团队（可折叠） =====
                ExpandableCard(
                    expanded = introExpanded,
                    onExpandedChange = { introExpanded = it },
                    header = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Group,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "开发团队",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    },
                    trailing = {
                        Text(
                            text = "2 位成员",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        MemberItem(qq = "577614508", position = "开发者")
                        MemberItem(qq = "2733977932", position = "原创(作者)")
                    }
                }

                Spacer(Modifier.height(12.dp))

                // ===== 检查更新 =====
                ClickableCard(
                    onClick = {
                        if (isCheckingUpdate) return@ClickableCard
                        isCheckingUpdate = true
                        scope.launch {
                            val latest = fetchLatestReleaseTag()
                            updateResult = when {
                                latest == null -> UpdateResult.Failed
                                isNewerVersion(latest, versionName) ->
                                    UpdateResult.HasUpdate(latest, versionName)
                                else -> UpdateResult.NoUpdate
                            }
                            isCheckingUpdate = false
                        }
                    }
                ) {
                    ListItem(
                        headlineContent = {
                            Text(if (isCheckingUpdate) "正在检查更新…" else "检查更新")
                        },
                        supportingContent = { Text("当前版本 $versionName") },
                        leadingContent = {
                            if (isCheckingUpdate) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    Icons.Rounded.Refresh,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    )
                }

                Spacer(Modifier.height(12.dp))

                // ===== 开源地址 =====
                ClickableCard(
                    onClick = {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                "https://github.com/$GITHUB_REPO".toUri()
                            )
                        )
                    }
                ) {
                    ListItem(
                        headlineContent = { Text("GitHub") },
                        supportingContent = { Text("github.com/$GITHUB_REPO") },
                        leadingContent = {
                            Icon(Icons.Rounded.Code, contentDescription = null)
                        }
                    )
                }

                Spacer(Modifier.height(12.dp))

                // ===== QQ 群 =====
                ClickableCard(
                    onClick = {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                "https://qun.qq.com/universal-share/share?ac=1&authKey=pV6gJ1assCshneDJQFTyUV8IrZ6EFS9uoIizWBvItPbDkHKh8wJreuFWjhaF7j%2B1&busi_data=eyJncm91cENvZGUiOiIxMDk4NjEwMTk2IiwidG9rZW4iOiJ2YzcxL1FSNFdsMWllZTIzSXliMjFaK3ZteEtwd0VHa3ZsUENrbTB4Uzd3SU5FR3JwU0Y0V2xHb3Q5U0U2V01UIiwidWluIjoiNTc3NjE0NTA4In0%3D&data=w-8D9EaNOLW-7zaf8Sn9GdRDq4fR5VWGG_iO9uHLiGs645zKZbj_Pcz0gdpgmsv_c03crPOMDY4xd-p5liJz_A&svctype=4&tempid=h5_group_info".toUri()
                            )
                        )
                    }
                ) {
                    ListItem(
                        headlineContent = { Text("QQ 群") },
                        supportingContent = { Text("1098610196") },
                        leadingContent = {
                            Icon(Icons.Rounded.Group, contentDescription = null)
                        }
                    )
                }

                Spacer(Modifier.height(12.dp))

                // ===== 赞助我们 =====
                ClickableCard(
                    onClick = { showSponsorDialog = true }
                ) {
                    ListItem(
                        headlineContent = { Text("赞助我们") },
                        supportingContent = { Text("一只小阿夜") },
                        leadingContent = {
                            Icon(Icons.Rounded.Favorite, contentDescription = null)
                        }
                    )
                }

                Spacer(Modifier.height(24.dp))
            }

            // ===== 底部：固定贴底，不滚动 =====
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "TestEasy",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Rounded.Favorite,
                        contentDescription = null,
                        tint = Color(0xFFE57373),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "by Xiaoye",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(8.dp))

                Text(
                    text = "Copyright © 2026 TestEasy xiaoye, All Rights Reserved.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // ===== 赞助弹窗 =====
    if (showSponsorDialog) {
        AlertDialog(
            onDismissRequest = { showSponsorDialog = false },
            title = { Text("赞助我们") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    SponsorItem(title = "支付宝", resId = R.drawable.ic_alipay_qr)
                    SponsorItem(title = "微信", resId = R.drawable.ic_wechat_qr)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSponsorDialog = false }) {
                    Text("关闭")
                }
            }
        )
    }

    // ===== 更新结果弹窗 =====
    updateResult?.let { result ->
        when (result) {
            is UpdateResult.HasUpdate -> {
                AlertDialog(
                    onDismissRequest = { updateResult = null },
                    title = { Text("发现新版本 🎉") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("当前版本：${result.currentVersion}")
                            Text("最新版本：${result.latestTag}")
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            updateResult = null
                            context.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    "https://github.com/$GITHUB_REPO/releases/latest".toUri()
                                )
                            )
                        }) { Text("前往更新") }
                    },
                    dismissButton = {
                        TextButton(onClick = { updateResult = null }) { Text("稍后") }
                    }
                )
            }

            UpdateResult.NoUpdate -> {
                AlertDialog(
                    onDismissRequest = { updateResult = null },
                    title = { Text("已是最新版本") },
                    text = { Text("当前版本 $versionName 已经是最新版了 🎉") },
                    confirmButton = {
                        TextButton(onClick = { updateResult = null }) { Text("好的") }
                    }
                )
            }

            UpdateResult.Failed -> {
                AlertDialog(
                    onDismissRequest = { updateResult = null },
                    title = { Text("检查失败") },
                    text = { Text("网络异常或 GitHub 无法访问，请稍后重试。") },
                    confirmButton = {
                        TextButton(onClick = { updateResult = null }) { Text("确定") }
                    }
                )
            }
        }
    }
}


// ==================================================================
// ===== 开发团队成员（QQ 头像） =====
// ==================================================================

data class QQInfoResponse(
    val code: Int? = null,
    val name: String? = null,
    val avatar: String? = null
)

data class MemberInfo(
    val name: String,
    val avatarUrl: String
)

private val qqHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()
}

private val qqGson: Gson by lazy { Gson() }

private val qqInfoCache = ConcurrentHashMap<String, MemberInfo>()

suspend fun fetchQQInfo(qq: String): MemberInfo? {
    qqInfoCache[qq]?.let { return it }

    return withContext(Dispatchers.IO) {
        try {
            val apiUrl = "http://39.106.191.161:1217/api/QQ_Info.php?qq=$qq"
            val request = Request.Builder().url(apiUrl).get().build()

            qqHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null

                val body = response.body?.string() ?: return@withContext null
                val qqInfo = qqGson.fromJson(body, QQInfoResponse::class.java)

                if (qqInfo.code == 200 &&
                    !qqInfo.avatar.isNullOrEmpty() &&
                    !qqInfo.name.isNullOrEmpty()
                ) {
                    val cleanAvatarUrl = qqInfo.avatar.replace("\\/", "/")
                    val info = MemberInfo(name = qqInfo.name, avatarUrl = cleanAvatarUrl)
                    qqInfoCache[qq] = info
                    info
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

@Composable
fun MemberItem(qq: String, position: String) {
    var memberInfo by remember { mutableStateOf<MemberInfo?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(qq) {
        isLoading = true
        memberInfo = fetchQQInfo(qq)
        isLoading = false
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when {
                isLoading -> {
                    Icon(
                        imageVector = Icons.Rounded.AccountCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                memberInfo != null -> {
                    val info = memberInfo!!
                    AsyncImage(
                        model = info.avatarUrl,
                        contentDescription = "${info.name} 的头像",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                else -> {
                    Icon(
                        imageVector = Icons.Rounded.AccountCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = memberInfo?.name ?: "加载中...",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "QQ: $qq",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Text(
                text = position,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}


// ==================================================================
// ===== 通用组件 =====
// ==================================================================

@Composable
fun ClickableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        content = content
    )
}

@Composable
private fun SponsorItem(
    title: String,
    @DrawableRes resId: Int
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            Image(
                painter = painterResource(id = resId),
                contentDescription = title,
                modifier = Modifier
                    .size(220.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
        }
    }
}

@Composable
fun ExpandableCard(
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    header: @Composable () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "rotation"
    )

    val headerShape: Shape = if (expanded) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    } else shape

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(headerShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(
                            bounded = true,
                            color = MaterialTheme.colorScheme.primary
                        )
                    ) { onExpandedChange(!expanded) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(modifier = Modifier.weight(1f)) { header() }

                if (trailing != null) {
                    trailing()
                    Spacer(Modifier.width(8.dp))
                }

                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = if (expanded) "收起" else "展开",
                    modifier = Modifier.rotate(rotation),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    content = content
                )
            }
        }
    }
}