package com.star.schedule.utils.parser.algorithms

import android.util.Log
import com.star.schedule.utils.parser.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.io.InputStream

/**
 * 简洁课表解析器
 *
 * 适配格式:
 * | A              | B      | C      | ... | H      |
 * | 节次           | 星期一 | 星期二 | ... | 星期日 |
 * | 第1节\n08:00-08:45 | 数学\n@李老师\n教学楼\n1-16周 | ... |
 *
 * 课程格支持 1~4 行:
 *   第1行: 课名 (必填)
 *   第2行: @教师 (可选, 以 @ 开头)
 *   第3行: 地点 (可选)
 *   第4行: 周次 (可选, 如 "1-16周" / "1-8,10-16周")
 *
 * 如果周次缺失, 使用 defaultWeeks。
 */
class SimpleTimetableParser : TimetableParser {
    override val name = "简洁课表"

    /** 没有周次时的默认周次 */
    private val defaultWeeks = (1..20).toList()

    override suspend fun parse(inputStream: InputStream): ParseResult? =
        withContext(Dispatchers.IO) {
            try {
                val workbook = HSSFWorkbook(inputStream)
                val sheet = workbook.getSheetAt(0)

                // ---------- 1. 表头 ----------
                val headerRow = sheet.getRow(0) ?: run {
                    workbook.close(); return@withContext null
                }

                // 解析星期列: B~H (col 1..7)
                val weekRegex = Regex("""(?:星期|周)\s*([一二三四五六日天])""")
                val weekCols = mutableMapOf<Int, Int>() // col -> weekDay
                for (col in 1 until headerRow.lastCellNum) {
                    val cell = headerRow.getCell(col) ?: continue
                    val text = cell.toString().trim()
                    val m = weekRegex.find(text) ?: continue
                    val day = when (m.groupValues[1]) {
                        "一" -> 1
                        "二" -> 2
                        "三" -> 3
                        "四" -> 4
                        "五" -> 5
                        "六" -> 6
                        "日", "天" -> 7
                        else -> continue
                    }
                    weekCols[col] = day
                }
                if (weekCols.isEmpty()) {
                    Log.e("SimpleParser", "未找到星期表头")
                    workbook.close()
                    return@withContext null
                }

                // ---------- 2. 节次时间 (A 列) ----------
                val timeSlotRegex =
                    Regex("""(\d{1,2}:\d{2})\s*[-~到]\s*(\d{1,2}:\d{2})""")
                val timeSlots = mutableListOf<ParsedTimeSlot>()
                val rowToPeriod = mutableMapOf<Int, Int>() // rowIndex -> period(从1开始)

                var periodIndex = 0
                for (rowIndex in 1..sheet.lastRowNum) {
                    val row = sheet.getRow(rowIndex) ?: continue
                    val cellA = row.getCell(0) ?: continue
                    val textA = cellA.toString()
                        .replace("\r\n", "\n")
                        .replace("\r", "\n")
                        .trim()
                    if (textA.isEmpty()) continue

                    val timeMatch = timeSlotRegex.find(textA) ?: continue
                    val start = timeMatch.groupValues[1]
                    val end = timeMatch.groupValues[2]
                    periodIndex++
                    timeSlots.add(ParsedTimeSlot(start, end))
                    rowToPeriod[rowIndex] = periodIndex
                }
                if (timeSlots.isEmpty()) {
                    Log.e("SimpleParser", "未找到节次时间")
                    workbook.close()
                    return@withContext null
                }

                // ---------- 3. 课程 ----------
                val courses = mutableListOf<ParsedCourse>()
                for ((rowIndex, period) in rowToPeriod) {
                    val row = sheet.getRow(rowIndex) ?: continue
                    for ((col, day) in weekCols) {
                        val cell = row.getCell(col) ?: continue
                        val cellText = cell.toString()
                            .replace("\r\n", "\n")
                            .replace("\r", "\n")
                            .trim()
                        if (cellText.isEmpty()) continue

                        val lines = cellText.lines()
                            .map { it.trim() }
                            .filter { it.isNotEmpty() }
                        if (lines.isEmpty()) continue

                        val courseName = lines.getOrNull(0).orEmpty()
                        if (courseName.isEmpty()) continue

                        // 第2行: @教师 或 直接是地点
                        val secondLine = lines.getOrNull(1).orEmpty()

                        val teacher: String
                        val location: String
                        val weeksText: String

                        if (secondLine.startsWith("@")) {
                            teacher = secondLine.removePrefix("@").trim()
                            location = lines.getOrNull(2).orEmpty()
                            weeksText = lines.getOrNull(3).orEmpty()
                        } else {
                            teacher = ""
                            location = secondLine
                            weeksText = lines.getOrNull(2).orEmpty()
                        }

                        val weeks = if (weeksText.isNotBlank()) {
                            parseWeeks(weeksText).ifEmpty { defaultWeeks }
                        } else {
                            defaultWeeks
                        }

                        courses.add(
                            ParsedCourse(
                                name = courseName,
                                teacher = teacher,
                                location = location,
                                weeks = weeks,
                                timeSlots = listOf(period),
                                weekDay = day
                            )
                        )
                    }
                }

                workbook.close()

                if (courses.isEmpty()) {
                    Log.e("SimpleParser", "未解析到任何课程")
                    return@withContext null
                }

                Log.d(
                    "SimpleParser",
                    "解析成功: ${courses.size} 门课, ${timeSlots.size} 个节次"
                )
                ParseResult(timeSlots = timeSlots, courses = courses)
            } catch (e: Exception) {
                Log.e("SimpleParser", "解析异常", e)
                null
            }
        }

    /** 解析 "1-16周" / "1-8,10-16周" / "1,3,5" */
    private fun parseWeeks(text: String): List<Int> {
        val result = mutableListOf<Int>()
        val cleaned = text.replace("周", "").trim()
        if (cleaned.isEmpty()) return result

        cleaned.split(",", "，").forEach { part ->
            val trimmed = part.trim()
            if (trimmed.isEmpty()) return@forEach

            val range = Regex("""(\d+)\s*-\s*(\d+)""").find(trimmed)
            if (range != null) {
                val s = range.groupValues[1].toIntOrNull() ?: return@forEach
                val e = range.groupValues[2].toIntOrNull() ?: return@forEach
                if (s <= e) {
                    for (w in s..e) result.add(w)
                }
            } else {
                trimmed.toIntOrNull()?.let { result.add(it) }
            }
        }
        return result.distinct().sorted()
    }
}