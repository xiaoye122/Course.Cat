package com.star.schedule

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.os.Process
import com.star.schedule.utils.SignatureGuard

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()

        if (!SignatureGuard.verify(this)) {
            Handler(Looper.getMainLooper()).postDelayed({
                Process.killProcess(Process.myPid())
            }, 5000)
        }
    }
}