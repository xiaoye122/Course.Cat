package com.star.schedule.utils

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

object SignatureGuard {
    private const val P1 = "F5EDB324"
    private const val P2 = "1E28FD63"
    private const val P3 = "DFE8C424"
    private const val P4 = "278DD3C5"
    private const val P5 = "B912F1DB"

    fun verify(context: Context): Boolean {
        val expected = P1 + P2 + P3 + P4 + P5
        return try {
            val pm = context.packageManager
            val signatures: Array<android.content.pm.Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
                val signingInfo = info.signingInfo
                    ?: return false
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                ).signatures ?: return false
            }

            signatures.any {
                sha1(it.toByteArray()).equals(expected, ignoreCase = true)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun sha1(data: ByteArray): String {
        val md = MessageDigest.getInstance("SHA1")
        return md.digest(data).joinToString("") { "%02x".format(it) }
    }
}