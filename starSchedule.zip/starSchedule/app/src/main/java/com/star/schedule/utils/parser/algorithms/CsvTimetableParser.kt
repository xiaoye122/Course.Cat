package com.star.schedule.utils.parser.algorithms

import com.star.schedule.utils.parser.ParseResult
import com.star.schedule.utils.parser.ParsedCourse
import com.star.schedule.utils.parser.ParsedTimeSlot
import com.star.schedule.utils.parser.TimetableParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

class CsvTimetableParser : TimetableParser {

    override val name: String = "CsvTimetableParser"

    override suspend fun parse(inputStream: InputStream): ParseResult? =
        withContext(Dispatchers.IO) {
            val text = try {
                inputStream.readBytes()
                    .toString(Charsets.UTF_8)
                    .removePrefix("\uFEFF")
            } catch (e: Exception) {
                return@withContext null
            }

            if (!text.contains("课程名称") || !text.contains("课程时间表")) {
                return@withContext null
            }

            val courses = mutableListOf<ParsedCourse>()
            val timeSlots = mutableListOf<ParsedTimeSlot>()

            var section = 0
            var headerSkipped = false

            text.lineSequence().forEach { raw ->
                val line = raw.trim()
                if (line.isEmpty()) return@forEach

                when {
                    line.contains("课程名称") -> {
                        section = 1
                        headerSkipped = false
                    }

                    line.startsWith("节次") && line.contains("开始时间") -> {
                        section = 2
                        headerSkipped = false
                    }

                    section == 1 -> {
                        if (!headerSkipped) {
                            headerSkipped = true
                            return@forEach
                        }
                        val c = splitCsvLine(line)
                        if (c.size >= 6) {
                            val courseName = c[0].trim()
                            val day = c[3].trim().toIntOrNull()
                            val periods = parseRange(c[4])
                            val weeks = parseRange(c[5])
                            if (courseName.isNotBlank() && day != null &&
                                periods.isNotEmpty() && weeks.isNotEmpty()
                            ) {
                                courses.add(
                                    ParsedCourse(
                                        name = courseName,
                                        teacher = c[1].trim(),
                                        weeks = weeks,
                                        location = c[2].trim(),
                                        timeSlots = periods,
                                        weekDay = day
                                    )
                                )
                            }
                        }
                    }

                    section == 2 -> {
                        if (!headerSkipped) {
                            headerSkipped = true
                            return@forEach
                        }
                        val c = splitCsvLine(line)
                        if (c.size >= 3) {
                            val start = c[1].trim()
                            val end = c[2].trim()
                            if (start.matches(TIME_REGEX) &&
                                end.matches(TIME_REGEX) &&
                                start != end
                            ) {
                                timeSlots.add(ParsedTimeSlot(start, end))
                            }
                        }
                    }
                }
            }

            if (courses.isEmpty()) return@withContext null
            ParseResult(timeSlots = timeSlots, courses = courses)
        }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        sb.append('"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                }

                c == ',' && !inQuotes -> {
                    result.add(sb.toString())
                    sb.clear()
                }

                else -> sb.append(c)
            }
            i++
        }
        result.add(sb.toString())
        return result
    }

    private fun parseRange(text: String): List<Int> {
        val cleaned = text.replace("周", "").trim()
        if (cleaned.isBlank()) return emptyList()
        val out = mutableListOf<Int>()
        cleaned.split(",").forEach { part ->
            val p = part.trim()
            if (p.contains("-")) {
                val pieces = p.split("-")
                if (pieces.size == 2) {
                    val s = pieces[0].trim().toIntOrNull()
                    val e = pieces[1].trim().toIntOrNull()
                    if (s != null && e != null && s <= e) out.addAll(s..e)
                }
            } else {
                p.toIntOrNull()?.let { out.add(it) }
            }
        }
        return out.distinct().sorted()
    }

    companion object {
        private val TIME_REGEX = Regex("""\d{1,2}:\d{2}""")
    }
}