package com.star.schedule.utils.parser.algorithms

import com.star.schedule.utils.parser.ParseResult
import com.star.schedule.utils.parser.ParsedCourse
import com.star.schedule.utils.parser.ParsedTimeSlot
import com.star.schedule.utils.parser.TimetableParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

class HtmlTimetableParser : TimetableParser {

    override val name: String = "HtmlTimetableParser"

    override suspend fun parse(inputStream: InputStream): ParseResult? =
        withContext(Dispatchers.IO) {
            val html = try {
                inputStream.readBytes().toString(Charsets.UTF_8)
            } catch (e: Exception) {
                return@withContext null
            }

            if (!html.contains("<table") || !html.contains("课程名称")) {
                return@withContext null
            }

            val courses = mutableListOf<ParsedCourse>()
            val timeSlots = mutableListOf<ParsedTimeSlot>()

            val tables = TABLE_REGEX.findAll(html)
                .map { it.groupValues[1] }
                .toList()

            tables.forEach { table ->
                val rows = ROW_REGEX.findAll(table)
                    .map { it.groupValues[1] }
                    .toList()

                if (rows.isEmpty()) return@forEach

                val firstCells = extractCells(rows[0])
                val isLessonTable = firstCells.firstOrNull()?.contains("节次") == true &&
                        firstCells.size >= 3 &&
                        firstCells.getOrNull(1)?.contains("开始") == true

                rows.drop(1).forEach { rowHtml ->
                    val cells = extractCells(rowHtml)
                    if (cells.all { it.isBlank() }) return@forEach

                    if (isLessonTable) {
                        if (cells.size >= 3) {
                            val s = cells[1].trim()
                            val e = cells[2].trim()
                            if (s.matches(TIME_REGEX) &&
                                e.matches(TIME_REGEX) &&
                                s != e
                            ) {
                                timeSlots.add(ParsedTimeSlot(s, e))
                            }
                        }
                    } else {
                        if (cells.size >= 6) {
                            val courseName = cells[0].trim()
                            val day = cells[3].trim().toIntOrNull()
                            val periods = parseRange(cells[4])
                            val weeks = parseRange(cells[5])
                            if (courseName.isNotBlank() && day != null &&
                                periods.isNotEmpty() && weeks.isNotEmpty()
                            ) {
                                courses.add(
                                    ParsedCourse(
                                        name = courseName,
                                        teacher = cells[1].trim(),
                                        weeks = weeks,
                                        location = cells[2].trim(),
                                        timeSlots = periods,
                                        weekDay = day
                                    )
                                )
                            }
                        }
                    }
                }
            }

            if (courses.isEmpty()) return@withContext null
            ParseResult(timeSlots = timeSlots, courses = courses)
        }

    private fun extractCells(rowHtml: String): List<String> =
        CELL_REGEX.findAll(rowHtml)
            .map { unescapeHtml(it.groupValues[1]).trim() }
            .toList()

    private fun unescapeHtml(s: String): String = s
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")

    private fun parseRange(text: String): List<Int> {
        val cleaned = text.replace("周", "").trim()
        if (cleaned.isBlank()) return emptyList()
        val out = mutableListOf<Int>()
        cleaned.split(",").forEach { part ->
            val p = part.trim()
            if (p.contains("-")) {
                val pieces = p.split("-")
                if (pieces.size == 2) {
                    val s = pieces[0].trim().toIntOrNull()
                    val e = pieces[1].trim().toIntOrNull()
                    if (s != null && e != null && s <= e) out.addAll(s..e)
                }
            } else {
                p.toIntOrNull()?.let { out.add(it) }
            }
        }
        return out.distinct().sorted()
    }

    companion object {
        private val TIME_REGEX = Regex("""\d{1,2}:\d{2}""")
        private val TABLE_REGEX =
            Regex("""<table[^>]*>(.*?)</table>""", RegexOption.DOT_MATCHES_ALL)
        private val ROW_REGEX =
            Regex("""<tr[^>]*>(.*?)</tr>""", RegexOption.DOT_MATCHES_ALL)
        private val CELL_REGEX =
            Regex("""<t[dh][^>]*>(.*?)</t[dh]>""", RegexOption.DOT_MATCHES_ALL)
    }
}